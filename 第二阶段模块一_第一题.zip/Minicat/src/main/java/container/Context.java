package container;

public class Context {

    private String name;
    private Wrapper[] wrappers;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Wrapper[] getWrappers() {
        return wrappers;
    }

    public void setWrappers(Wrapper[] wrappers) {
        this.wrappers = wrappers;
    }
}
