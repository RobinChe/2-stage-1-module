package server;

import container.Context;
import container.Host;
import container.Wrapper;

import java.io.InputStream;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

public class RequestProcessor extends Thread {

    private Socket socket;
    private Map<String, Map<String,HttpServlet>> contextMap;


    /*public RequestProcessor(Socket socket, Map<String, HttpServlet> servletMap) {
        this.socket = socket;
        this.servletMap = servletMap;
    }*/

    public RequestProcessor(Socket socket, Host[] hosts) {
        this.socket = socket;
        this.contextMap = getContextMapFromHosts(hosts);
    }

    @Override
    public void run() {
        try{
            InputStream inputStream = socket.getInputStream();

            // 封装Request对象和Response对象
            Request request = new Request(inputStream);
            Response response = new Response(socket.getOutputStream());

            String url = request.getUrl();
            String contextName = url.split("/")[1];
            String servletUrl = url.substring(contextName.length() + 1, url.length());
            if(contextMap.get(contextName) == null) {
                System.out.println("没有找到相关的context");
                response.output(HttpProtocolUtil.getHttpHeader404());
            } else {
                Map<String, HttpServlet> servletMap = contextMap.get(contextName);
                // 静态资源处理
                if(servletMap.get(servletUrl) == null) {
                    response.outputHtml(request.getUrl());
                } else {
                    //动态资源servlet 请求
                    HttpServlet httpServlet = servletMap.get(servletUrl);
                    httpServlet.service(request, response);
                }
            }
            socket.close();

        }catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static void main(String[] args) {
        String s = "/demo/test/resume";
        String s1 = s.split("/")[1];
        String s2 = s.substring(s1.length() + 1, s.length());
        System.out.println(s1);
        System.out.println(s2);
    }

    private Map<String, Map<String, HttpServlet>> getContextMapFromHosts(Host[] hosts) {
        Map<String, Map<String, HttpServlet>> contextMap = new HashMap<>();
        for (int i = 0; i < hosts.length; i++) {
            Host host = hosts[i];
            Context[] contexts = host.getContexts();
            for (int j = 0; j < contexts.length; j++) {
                Context context = contexts[j];
                String contextName = context.getName();
                Wrapper[] wrappers = context.getWrappers();
                Map<String, HttpServlet> servletMap = getServletMapFromWrappers(wrappers);
                contextMap.put(contextName, servletMap);
            }
        }
        return contextMap;
    }

    private Map<String, HttpServlet> getServletMapFromWrappers(Wrapper[] wrappers) {
        Map<String, HttpServlet> servletMap = new HashMap<>();
        for (int i = 0; i < wrappers.length; i++) {
            Wrapper wrapper = wrappers[i];
            servletMap.put(wrapper.getName(), wrapper.getServlet());
        }
        return servletMap;
    }
}
