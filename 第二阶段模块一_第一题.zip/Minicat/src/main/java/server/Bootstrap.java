package server;

import container.Context;
import container.Host;
import container.Mapper;
import container.Wrapper;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

/**
 * Minicat的主类
 */
public class Bootstrap {

    /**定义socket监听的端口号*/
    /*private int port = 8080;

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }*/


    /**
     * Minicat启动需要初始化展开的一些操作
     */
    public void start() throws Exception {

        // 加载解析相关的配置，web.xml
        loadServlet();


        // 定义一个线程池
        int corePoolSize = 10;
        int maximumPoolSize =50;
        long keepAliveTime = 100L;
        TimeUnit unit = TimeUnit.SECONDS;
        BlockingQueue<Runnable> workQueue = new ArrayBlockingQueue<>(50);
        ThreadFactory threadFactory = Executors.defaultThreadFactory();
        RejectedExecutionHandler handler = new ThreadPoolExecutor.AbortPolicy();


        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(
                corePoolSize,
                maximumPoolSize,
                keepAliveTime,
                unit,
                workQueue,
                threadFactory,
                handler
        );





        /*
            完成Minicat 1.0版本
            需求：浏览器请求http://localhost:8080,返回一个固定的字符串到页面"Hello Minicat!"
         */
        /*ServerSocket serverSocket = new ServerSocket(port);
        System.out.println("=====>>>Minicat start on port：" + port);*/

        /*while(true) {
            Socket socket = serverSocket.accept();
            // 有了socket，接收到请求，获取输出流
            OutputStream outputStream = socket.getOutputStream();
            String data = "Hello Minicat!";
            String responseText = HttpProtocolUtil.getHttpHeader200(data.getBytes().length) + data;
            outputStream.write(responseText.getBytes());
            socket.close();
        }*/


        /**
         * 完成Minicat 2.0版本
         * 需求：封装Request和Response对象，返回html静态资源文件
         */
        /*while(true) {
            Socket socket = serverSocket.accept();
            InputStream inputStream = socket.getInputStream();

            // 封装Request对象和Response对象
            Request request = new Request(inputStream);
            Response response = new Response(socket.getOutputStream());

            response.outputHtml(request.getUrl());
            socket.close();

        }*/


        /**
         * 完成Minicat 3.0版本
         * 需求：可以请求动态资源（Servlet）
         */
        /*while(true) {
            Socket socket = serverSocket.accept();
            InputStream inputStream = socket.getInputStream();

            // 封装Request对象和Response对象
            Request request = new Request(inputStream);
            Response response = new Response(socket.getOutputStream());

            // 静态资源处理
            if(servletMap.get(request.getUrl()) == null) {
                response.outputHtml(request.getUrl());
            }else{
                // 动态资源servlet请求
                HttpServlet httpServlet = servletMap.get(request.getUrl());
                httpServlet.service(request,response);
            }

            socket.close();

        }
*/

        /*
            多线程改造（不使用线程池）
         */
        /*while(true) {
            Socket socket = serverSocket.accept();
            RequestProcessor requestProcessor = new RequestProcessor(socket,servletMap);
            requestProcessor.start();
        }*/


        if(mapper != null) {
            int port = mapper.getPort();

            ServerSocket serverSocket = new ServerSocket(port);
            System.out.println("=====>>>Minicat start on port：" + port);
            System.out.println("=========>>>>>>使用线程池进行多线程改造");

            /*
            多线程改造（使用线程池）
            */
            while(true) {
                Socket socket = serverSocket.accept();
                RequestProcessor requestProcessor = new RequestProcessor(socket,mapper.getHosts());
                //requestProcessor.start();
                threadPoolExecutor.execute(requestProcessor);
            }

        }




    }


    //private Map<String,HttpServlet> servletMap = new HashMap<String,HttpServlet>();

    private Mapper mapper = new Mapper();

    /**
     * 加载解析web.xml，初始化Servlet
     */
    private void loadServlet() throws DocumentException {

        InputStream resourceAsStream = this.getClass().getClassLoader().getResourceAsStream("service.xml");
        SAXReader saxReader = new SAXReader();

        try {
            Document document = saxReader.read(resourceAsStream);
            Element rootElement = document.getRootElement();

            Element serviceElement = (Element) rootElement.selectSingleNode("//Service");

            Element connectorElement = (Element) serviceElement.selectSingleNode("Connector");
            String port = connectorElement.attributeValue("port");
            mapper.setPort(Integer.parseInt(port));

            Element engineElement = (Element) serviceElement.selectSingleNode("Engine");
            List<Element> hostNodes = engineElement.selectNodes("//Host");
            List<Host> hostList = new ArrayList<>();
            for (int i = 0; i < hostNodes.size(); i++) {
                Element element = hostNodes.get(i);
                String name = element.attributeValue("name");
                String appBase = element.attributeValue("appBase");

                Host host = new Host();
                host.setName(name);
                host.setAppBase(appBase);
                Context[] contexts = getContextFromAppBase(appBase);
                if (contexts == null)
                    continue;
                host.setContexts(contexts);
                hostList.add(host);
            }

            if (hostList.size() == 0)
                throw new RuntimeException("没有加载到Host配置信息");

            mapper.setHosts(hostList.toArray(new Host[hostList.size()]));
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    private Context[] getContextFromAppBase(String appBase) {
        File appBaseFile = new File(appBase);
        File[] files = appBaseFile.listFiles(pathname -> pathname.isDirectory());
        if(files == null || files.length == 0) {
            System.out.println("该路径没有发现部署的项目:" + appBase);
            return null;
        }
        List<Context> contextList = new ArrayList<>();
        for (File file : files) {
            Context context = new Context();
            String contextName = file.getName();

            Wrapper[] wrappers = getWrappersFromContext(appBase + File.separator + contextName);
            if (wrappers == null) {
                continue;
            }
            context.setName(contextName);
            context.setWrappers(wrappers);
            contextList.add(context);
        }

        if(contextList.size() == 0)
            return null;
        return contextList.toArray(new Context[contextList.size()]);
    }

    /**
     * 发现 wrapper
     * @param contextPath
     * @return
     */
    private Wrapper[] getWrappersFromContext(String contextPath) {
        try {
            InputStream resourceAsStream = new FileInputStream(contextPath + File.separator + "web.xml");
            SAXReader saxReader = new SAXReader();

            Document document = saxReader.read(resourceAsStream);
            Element rootElement = document.getRootElement();

            List<Wrapper> wrapperList = new ArrayList<>();
            List<Element> selectNodes = rootElement.selectNodes("//servlet");
            for (int i = 0; i < selectNodes.size(); i++) {
                Element element =  selectNodes.get(i);
                // <servlet-name>lagou</servlet-name>
                Element servletnameElement = (Element) element.selectSingleNode("servlet-name");
                String servletName = servletnameElement.getStringValue();
                // <servlet-class>server.LagouServlet</servlet-class>
                Element servletclassElement = (Element) element.selectSingleNode("servlet-class");
                String servletClass = servletclassElement.getStringValue();


                // 根据servlet-name的值找到url-pattern
                Element servletMapping = (Element) rootElement.selectSingleNode("/web-app/servlet-mapping[servlet-name='" + servletName + "']");
                // /lagou
                String urlPattern = servletMapping.selectSingleNode("url-pattern").getStringValue();

                Wrapper wrapper = new Wrapper();
                wrapper.setName(urlPattern);
                wrapper.setServlet((HttpServlet) Class.forName(servletClass).newInstance());
                wrapperList.add(wrapper);
            }

            if(wrapperList.size() == 0)
                return null;
            return wrapperList.toArray(new Wrapper[wrapperList.size()]);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    /**
     * Minicat 的程序启动入口
     * @param args
     */
    public static void main(String[] args) {
        Bootstrap bootstrap = new Bootstrap();
        try {
            // 启动Minicat
            bootstrap.start();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
